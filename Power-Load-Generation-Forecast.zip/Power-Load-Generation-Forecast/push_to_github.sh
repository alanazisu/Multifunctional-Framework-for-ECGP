#!/bin/bash
# ============================================================
#  push_to_github.sh
#  Run this script once to push the full codebase to GitHub.
#  Usage:  bash push_to_github.sh
# ============================================================

REPO_URL="https://github.com/alanazisu/Power-Load-Generation-Forecast.git"

echo "Initialising git repository..."
git init
git remote add origin "$REPO_URL" 2>/dev/null || git remote set-url origin "$REPO_URL"

echo "Staging all files..."
git add .

echo "Committing..."
git commit -m "Initial commit: Energy-TSN Two-Stream Network

- Stream 1: Energy Spatial Network (GradientBoosting on 26 cross-features)
- Stream 2: Energy Temporal Network (RandomForest on 24h look-back sequences)
- Fusion Layer: Ridge Regression with learned alpha-weighting
- Multi-granularity evaluation: hourly, daily, weekly, monthly
- 14 publication-quality result figures
- Full metrics: MSE, RMSE, MAE, MAPE, SMAPE, R2, CVRMSE
- Results: Consumption R2=0.9613 | Solar R2=0.9972 (hourly)"

echo "Pushing to GitHub..."
git branch -M main
git push -u origin main --force

echo "Done! Visit: $REPO_URL"
